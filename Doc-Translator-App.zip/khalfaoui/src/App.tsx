import React, { useState, useRef, useEffect } from "react";

const LANGUAGES = [
  { code: "en", label: "الإنجليزية – English" },
  { code: "fr", label: "الفرنسية – French" },
  { code: "es", label: "الإسبانية – Spanish" },
  { code: "de", label: "الألمانية – German" },
  { code: "zh", label: "الصينية – Chinese" },
  { code: "ru", label: "الروسية – Russian" },
  { code: "tr", label: "التركية – Turkish" },
  { code: "it", label: "الإيطالية – Italian" },
  { code: "pt", label: "البرتغالية – Portuguese" },
  { code: "ja", label: "اليابانية – Japanese" },
  { code: "ko", label: "الكورية – Korean" },
  { code: "ar", label: "العربية – Arabic" },
];

// openai api key (replace with secure storage in production!)
const OPENAI_API_KEY = "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";

function App() {
  const [selectedLang, setSelectedLang] = useState("auto");
  const [files, setFiles] = useState([]); // {file, state: "idle"|"translating"|"done"|"error", translatedText: string|null}
  const fileInputRef = useRef(null);

  // الوضع الليلي
  const [dark, setDark] = useState(false);

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [dark]);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const selected = Array.from(e.target.files || []);
    const valid = selected.filter(f => /pdf|docx|txt$/i.test(f.name));
    setFiles(prev => [...prev, ...valid.map(file => ({ file, state: "idle", translatedText: null }))]);
    e.target.value = "";
  };

  const handleRemoveFile = (idx) => {
    setFiles(files => files.filter((_, i) => i !== idx));
  };

  // ترجمة ملف نصي عبر OpenAI
  async function translateTxtFile(file, targetLanguage, idx) {
    let text = await file.text();
    try {
      setFiles(prev => {
        const next = [...prev];
        next[idx].state = "translating";
        return next;
      });
      const completion = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-3.5-turbo",
          messages: [
            {role: "system", content: `ترجم النص التالي إلى ${LANGUAGES.find(l => l.code===targetLanguage)?.label || targetLanguage}. أعد تنسيق الفقرات كما هي، بدون شرح أو إضافات:`},
            {role: "user", content: text}
          ],
          max_tokens: 2048
        })
      });
      const data = await completion.json();
      if (data.choices && data.choices[0]?.message?.content) {
        setFiles(prev => {
          const next = [...prev];
          next[idx].state = "done";
          next[idx].translatedText = data.choices[0].message.content;
          return next;
        });
      } else {
        throw new Error("ترجمة غير متوقعة");
      }
    } catch(e) {
      setFiles(prev => {
        const next = [...prev];
        next[idx].state = "error";
        return next;
      });
    }
  }

  // ترجمة كل الملفات النصية
  const handleTranslateAll = () => {
    files.forEach((f, i) => {
      if (/txt$/i.test(f.file.name)) {
        translateTxtFile(f.file, selectedLang === "auto" ? "en" : selectedLang, i);
      }
    });
  };

  // تنزيل الملف المترجم
  const handleDownloadTranslated = (idx) => {
    const item = files[idx];
    if (item?.translatedText) {
      try {
        const blob = new Blob([item.translatedText], {type: "text/plain"});
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        // اسم ملف دائمًا ينتهي بـ _translated.txt
        const name = item.file.name.replace(/\.(txt)?$/i, "") + "_translated.txt";
        link.download = name;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
      } catch (e) {
        alert("حدث خطأ أثناء تحميل الملف!");
      }
    } else {
      alert("الترجمة غير متوفرة بعد أو فشلت العملية.");
    }
  };

  // زر تحميل الكل: تحميل كل الملفات المترجمة فقط
  const handleDownloadAll = () => {
    let anyDownloaded = false;
    files.forEach((item, idx) => {
      if (item.state === "done" && item.translatedText) {
        handleDownloadTranslated(idx);
        anyDownloaded = true;
      }
    });
    if (!anyDownloaded) {
      alert("لا توجد ترجمات متوفرة للتحميل.");
    }
  };

  // Helper to determine if "تحميل الكل" should be enabled
  const canDownloadAll = files.some(f => f.state === "done" && f.translatedText);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground">
      <div className="max-w-md w-full flex flex-col items-center">
        <h1 className="text-4xl font-bold">Khalfaoui Translator</h1>
        <p className="mt-4 text-lg opacity-80">ترجم مستنداتك بسهولة واحترافية</p>
        <div className="mt-10 w-full flex flex-col space-y-4">
          <button onClick={() => { alert('رفع ملف يعمل!'); handleUploadClick(); }} className="w-full py-2 px-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition">
            رفع ملف
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.docx,.txt"
            multiple
            hidden
          />

          <div className="w-full flex flex-col space-y-1">
            <label className="text-right pr-1 font-medium opacity-80">
              اختر لغة الترجمة
            </label>
            <select
              className="w-full rounded-lg border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary text-right"
              value={selectedLang}
              onChange={e => setSelectedLang(e.target.value)}
            >
              <option value="auto">الكشف التلقائي عن اللغة – Auto Detect</option>
              {LANGUAGES.map(lang => (
                <option value={lang.code} key={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>

          <button onClick={() => { alert('ترجمة الكل تعمل!'); handleTranslateAll(); }} className="w-full py-2 px-4 bg-accent text-foreground rounded-lg font-semibold hover:bg-accent/90 transition">
            ترجمة الكل
          </button>
          <button
            className="w-full py-2 px-4 bg-foreground text-background rounded-lg font-semibold hover:bg-foreground/90 transition"
            onClick={() => { alert('تحميل الكل يعمل!'); handleDownloadAll(); }}
            disabled={!canDownloadAll}
            style={{
              pointerEvents: canDownloadAll ? "auto" : "none",
              filter: canDownloadAll ? "none" : "grayscale(0.5)",
              // لا نستخدم opacity/cursor لتعطيل الزر فعلياً
            }}
          >
            تحميل الكل
          </button>
          <button
            className="w-full py-2 px-4 border border-ring rounded-lg font-semibold hover:bg-muted transition"
            onClick={() => setDark(d => !d)}
          >
            تبديل الوضع الليلي
          </button>
        </div>

        {files.length > 0 && (
          <div className="mt-8 w-full">
            <table className="w-full text-sm border bg-muted rounded-lg overflow-hidden">
              <thead>
                <tr>
                  <th className="font-medium py-2">اسم الملف</th>
                  <th className="font-medium py-2">الحجم</th>
                  <th className="font-medium py-2">الحالة</th>
                  <th className="font-medium py-2">تحميل</th>
                  <th className="font-medium py-2">حذف</th>
                </tr>
              </thead>
              <tbody>
                {files.map((f, i) => (
                  <tr key={i} className="border-t">
                    <td className="py-2 px-2">{f.file.name}</td>
                    <td className="py-2 px-2">{(f.file.size / 1024).toFixed(1)} KB</td>
                    <td className="py-2 px-2">
                      {(/txt$/i.test(f.file.name)) ? (
                        {
                          "idle": "بانتظار الترجمة",
                          "translating": "جاري الترجمة...",
                          "done": "مكتمل",
                          "error": "فشل"
                        }[f.state]
                      ) : (
                        <span className="opacity-50">PDF/DOCX قريبًا</span>
                      )}
                    </td>
                    <td className="py-2 px-2 text-center">
                      {f.state === "done" && f.translatedText ? (
                        <button
                          onClick={() => { alert('تحميل الملف يعمل!'); handleDownloadTranslated(i); }}
                          className="text-blue-600 hover:underline font-bold"
                        >
                          تحميل
                        </button>
                      ) : (
                        <button
                          disabled
                          style={{
                            pointerEvents: "none",
                            filter: "grayscale(0.5)"
                          }}
                          className="text-gray-400 font-bold"
                          title={
                            f.state === "error"
                              ? "فشل الترجمة"
                              : "الترجمة غير متوفرة بعد"
                          }
                        >
                          تحميل
                        </button>
                      )}
                    </td>
                    <td className="py-2 px-2 text-center">
                      <button onClick={() => handleRemoveFile(i)} className="text-red-500 font-bold hover:underline">حذف</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
